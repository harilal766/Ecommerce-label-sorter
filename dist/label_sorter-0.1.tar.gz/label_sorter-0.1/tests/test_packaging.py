from filepaths import *

class Test_Packaging:
    def test_requirements(self):
        assert required_dependencies